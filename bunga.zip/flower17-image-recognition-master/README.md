# flower17-image-recognition
Example project implementing image recognition in python.

It was build around [this](https://gogul09.github.io/software/image-classification-python) tutorial.